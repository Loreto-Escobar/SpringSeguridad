package com.modulo.seguridad.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/usuario")
public class HomeController {
	
		@GetMapping("/")
		public ModelAndView home() {
			ModelAndView modelAndView = new ModelAndView("user/home");
			return modelAndView;		
		}
		
		@PostMapping("/usuario")
		public ModelAndView usuario() {
			ModelAndView modelAndView = new ModelAndView("user/usuario");
			
			return modelAndView;
		}
}
