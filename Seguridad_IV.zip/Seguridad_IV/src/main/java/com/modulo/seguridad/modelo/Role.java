package com.modulo.seguridad.modelo;

public enum Role {

	ADMIN, USER
}
