package com.modulo.seguridad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Seguridad_IVApplication {

	public static void main(String[] args) {
		SpringApplication.run(Seguridad_IVApplication.class, args);
	}

}
