 package com.modulo.seguridad.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.modulo.seguridad.modelo.User;

@Mapper
public interface UserMapper {

	@Select("select * from users where email=#{email}")
	public User findByEmail(@Param("email") String email);
}
