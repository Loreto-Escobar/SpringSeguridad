package com.modulo.seguridad.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.modulo.seguridad.CustomAuthenticationSuccessHandler;
import com.modulo.seguridad.service.AuthUserDetails;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Autowired
	CustomAuthenticationSuccessHandler customAuthenticationSuccessHandler;
	
	@Autowired
	AuthUserDetails authUserDetails;

	@Bean
	public BCryptPasswordEncoder encoder() {
		return new BCryptPasswordEncoder();
	}
		
	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(authUserDetails).passwordEncoder(encoder());					
	}

	@Override
	public void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers("/usuario/**").hasAuthority("USER")
								.antMatchers("/admin/**").hasAuthority("ADMIN")
								.antMatchers("/login").permitAll()
								.anyRequest().authenticated()
								.and()
								.formLogin()
								.loginPage("/login")
								.successHandler(customAuthenticationSuccessHandler)
								.failureUrl("/login?error=true")
								.usernameParameter("username")
								.passwordParameter("password")
								.and()
								.exceptionHandling()
								.accessDeniedPage("/recurso-prohibido");
		
	}
	
	
	
	
	
}
