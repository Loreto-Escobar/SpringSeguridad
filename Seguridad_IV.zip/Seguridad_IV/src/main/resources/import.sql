create table users(email varchar, password varchar, role varchar);
insert into users(email, password, role) values('guido@mail.com','$2a$10$T4xQ89SRAZJbA5GrwtkwhuuY9dK4yCsEsu6FC5qyF.pjY2.WlC0gS','USER');
insert into users(email, password, role) values ('james@mail.com','$2a$10$Ypnx5m1ocFKWpIHqhg013eb/pQvDTgFNMT1v3UEyKMmoCNe0ztn2S','ADMIN');
