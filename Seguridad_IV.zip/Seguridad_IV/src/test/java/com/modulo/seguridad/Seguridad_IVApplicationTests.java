package com.modulo.seguridad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Seguridad_IVApplicationTests {

	@Test
	void contextLoads() {
	}

}
