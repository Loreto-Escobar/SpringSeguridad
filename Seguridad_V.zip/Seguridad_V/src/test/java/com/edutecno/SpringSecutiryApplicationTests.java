package com.edutecno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecutiryApplicationTests {

	@Test
	void contextLoads() {
	}

}
