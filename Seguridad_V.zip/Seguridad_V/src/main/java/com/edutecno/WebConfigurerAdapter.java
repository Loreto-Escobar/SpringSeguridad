package com.edutecno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.edutecno.service.AuthUserDetails;

@Configuration
@EnableWebSecurity
public class WebConfigurerAdapter extends WebSecurityConfigurerAdapter{
	
	@Autowired
	CustomAuthenticationSuccessHandler customAuthenticationSuccessHandler;
	
	@Autowired
	AuthUserDetails authUserDetails;
	
	@Bean
	public BCryptPasswordEncoder encoder() {
		return new BCryptPasswordEncoder();
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
		auth.userDetailsService(authUserDetails).passwordEncoder(encoder());
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		http.authorizeRequests().antMatchers("/usuario/**").hasAuthority("USER")
								.antMatchers("/admin/**").hasAuthority("ADMIN")
								.antMatchers("/login").permitAll()
								.anyRequest().authenticated()
								.and()
								.formLogin().loginPage("/login")
								.successHandler(customAuthenticationSuccessHandler)
								.usernameParameter("username")
								.passwordParameter("password")
								.and()
								.exceptionHandling().accessDeniedPage("/recurso-prohibido");
	}

	
}
