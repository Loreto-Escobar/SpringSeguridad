package com.edutecno.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

	@GetMapping("/login")
	public ModelAndView login(@RequestParam(value = "error", required = false) String error,
			Model modelo) {
		ModelAndView mav = new ModelAndView("login");
		if(error != null) {
			modelo.addAttribute("error", "ingresa tus credenciales!");
		}
		return mav;
	}
	
}
