package com.edutecno.modelo;

public enum Role {

	ADMIN, USER
	
}
